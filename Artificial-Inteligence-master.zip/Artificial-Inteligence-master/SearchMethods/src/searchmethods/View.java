
package searchmethods;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

/**
 *
 * @author Tania V
 */
public class View extends JFrame {
    private JButton b1,b2,b3,b4,b5;
    private JPanel boton;
    
    
    /**
     * maze[fila][columna]
     * 
     * valores: 
     * 0 -> nodo sin visitar (camino en blanco)
     * 1 -> pared (obstaculo)
     * 2 -> nodo visitado
     * 9 -> objetivo
     * 
    */
    
      int [][] maze = {
          
     {1, 1, 1, 1, 1, 1, 1, 1, 1, 1 },
     {1, 0, 1, 0, 1, 0, 0, 0, 1, 1 }, //<- inicio (1,1)
     {1, 0, 1, 0, 0, 1, 0, 1, 9, 1 }, //<- objetivo (2,8)
     {1, 0, 0, 0, 1, 0, 0, 0, 0, 1 },
     {1, 0, 1, 0, 0, 1, 1, 0, 1, 1 },
     {1, 0, 1, 0, 1, 1, 0, 0, 0, 1 },
     {1, 0, 0, 0, 0, 0, 0, 0, 0, 1 },
     {1, 0, 1, 0, 1, 0, 0, 1, 0, 1 },
     {1, 1, 1, 1, 1, 1, 1, 1, 1, 1 }
              
     };    
     
    
  /* int [][] maze = {
       
  {1,1,1,1,1,1,1,1,1,1,1,1,1},
  {1,0,1,0,1,0,1,0,0,0,0,0,1}, // inicio (5,1)
  {1,0,1,0,0,0,1,0,0,1,1,0,1},
  {1,0,0,0,1,1,1,0,1,0,0,0,1},
  {1,0,1,0,0,0,0,0,1,1,1,0,1},
  {1,0,1,0,1,1,1,0,1,0,0,0,1},
  {1,0,1,0,1,9,0,0,1,1,1,0,1},
  {1,0,1,0,1,1,1,0,1,0,1,0,1},
  {1,0,0,0,0,0,0,0,0,0,1,0,1},  // 9 -> objetivo (11,8)
  {1,1,1,1,1,1,1,1,1,1,1,1,1}

    };*/
   private final List<Integer> path = new ArrayList<Integer>();
   
   public View(){
       
       setTitle("MAZE SOLVER");
       setSize(640,640);
       setLocationRelativeTo(null);
       setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       setResizable(false);
       b1 = new JButton("DepthFirstSearch");
       b2 = new JButton("BreadthFirstSearchFS");
       b3 = new JButton("Hill Climbing");
       b4 = new JButton("A*");
       b5 = new JButton("Best First Search");
       
       
       boton = new JPanel();
       
       boton.setLayout(new GridLayout(20,0));
            boton.add(b1); boton.add(b5);
            boton.add(b2);
            boton.add(b3);
            boton.add(b4);
            
            add(boton,"East");
            
       DepthFirstSearch.searchPath(maze, 1, 1, path);
       System.out.println(path);
       
       
   } 
   
   @Override
   public void paint (Graphics g){
       super.paint(g);
       g.translate(50,50);
       
       for(int fila=0; fila < maze.length; fila++){
          for(int columna=0; columna < maze[0].length; columna++){
             Color color;
                switch(maze[fila][columna]){
                    case 1: color = Color.darkGray; break;
                    case 9: color = Color.RED; break;
                    default: color = Color.WHITE; 
                }
                g.setColor(color);
                g.fillRect(30*columna, 30*fila, 30 , 30);
                g.setColor(Color.BLACK);
                g.drawRect(30*columna, 30*fila, 30 , 30);
          } 
       }
       // COLOREA EL CAMINO DESDE EL PUNTO DE INICIO
       for(int c = 0; c < path.size(); c+=2){
           int caminoX = path.get(c);
           int caminoY = path.get(c + 1);
           g.setColor(Color.PINK);
           g.fillRect(caminoX * 30, caminoY * 30, 28, 28);
       }
       
   }
   
 
  
   public static void main(String [] args){
       SwingUtilities.invokeLater(() -> {
           View view = new View();
           view.setVisible(true);
       });
            
   }
   
   
   
   
   
   
   
   
   
   
   
   
}
