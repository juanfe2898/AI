# Artificial-Inteligence
Minimax project (tic-tac-toe) and Search Algorithms
